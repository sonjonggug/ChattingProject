host = WScript.Arguments(0).replace(/nnssh:/,"").replace(/\//g,"").replace(/%20/g," ").replace(/%5C/g,"\\");
shell = WScript.CreateObject("WScript.Shell");
shell.Run("\"C:/NeonexSoft/URLprotocol/putty.exe\"" + host);