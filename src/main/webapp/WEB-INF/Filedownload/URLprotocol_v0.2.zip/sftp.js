host = WScript.Arguments(0).replace(/nnsftp:\/\//,"").replace(/%20/g," ").replace(/%5C/g,"\\");
shell = WScript.CreateObject("WScript.Shell");
shell.Run("\"C:/NeonexSoft/URLprotocol/FileZilla FTP Client/filezilla.exe\"" + host);